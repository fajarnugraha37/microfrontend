import { createVuexModulePiniaStore as importedFactory } from '../../createVuexModulePiniaStore'
export const createVuexModulePiniaStore = importedFactory
